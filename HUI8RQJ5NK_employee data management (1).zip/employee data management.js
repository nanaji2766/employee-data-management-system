const API = {
    baseUrl: 'https://jsonplaceholder.typicode.com/users',

    async getUsers() {
        try {
            const response = await fetch(this.baseUrl);
            if (!response.ok) throw new Error('Failed to fetch users');
            return await response.json();
        } catch (error) {
            throw error;
        }
    },

    async getUser(id) {
        try {
            const response = await fetch(`${this.baseUrl}/${id}`);
            if (!response.ok) throw new Error('Failed to fetch user');
            return await response.json();
        } catch (error) {
            throw error;
        }
    },

    async createUser(userData) {
        try {
            const response = await fetch(this.baseUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData)
            });
            if (!response.ok) throw new Error('Failed to create user');
            return await response.json();
        } catch (error) {
            throw error;
        }
    },

    async updateUser(id, userData) {
        try {
            const response = await fetch(`${this.baseUrl}/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData)
            });
            if (!response.ok) throw new Error('Failed to update user');
            return await response.json();
        } catch (error) {
            throw error;
        }
    },

    async deleteUser(id) {
        try {
            const response = await fetch(`${this.baseUrl}/${id}`, {
                method: 'DELETE'
            });
            if (!response.ok) throw new Error('Failed to delete user');
            return true;
        } catch (error) {
            throw error;
        }
    }
};
class UserService {
    constructor() {
        this.users = [];
        this.currentPage = 1;
        this.usersPerPage = 6;
        this.initializeElements();
        this.addEventListeners();
        this.loadUsers();
    }

    initializeElements() {
        this.userList = document.getElementById('userList');
        this.userModal = document.getElementById('userModal');
        this.userForm = document.getElementById('userForm');
        this.errorContainer = document.getElementById('errorContainer');
        this.modalTitle = document.getElementById('modalTitle');
        this.pagination = {
            prevBtn: document.getElementById('prevPage'),
            nextBtn: document.getElementById('nextPage'),
            pageInfo: document.getElementById('pageInfo')
        };
    }

    addEventListeners() {
        document.getElementById('addUserBtn').addEventListener('click', () => this.showModal());
        document.querySelector('.close').addEventListener('click', () => this.closeModal());
        this.userForm.addEventListener('submit', (e) => this.handleSubmit(e));
        this.pagination.prevBtn.addEventListener('click', () => this.changePage(-1));
        this.pagination.nextBtn.addEventListener('click', () => this.changePage(1));
    }

    async loadUsers() {
        try {
            this.users = await API.getUsers();
            this.renderUsers();
            this.updatePagination();
        } catch (error) {
            this.showError(error.message);
        }
    }

    renderUsers() {
        const start = (this.currentPage - 1) * this.usersPerPage;
        const end = start + this.usersPerPage;
        const paginatedUsers = this.users.slice(start, end);

        this.userList.innerHTML = paginatedUsers.map(user => `
            <div class="user-card">
                <h3>${user.name}</h3>
                <p>ID: ${user.id}</p>
                <p>Email: ${user.email}</p>
                <p>Department: ${user.company.name}</p>
                <div class="user-card-actions">
                    <button class="btn btn-primary" onclick="userService.editUser(${user.id})">Edit</button>
                    <button class="btn btn-danger" onclick="userService.deleteUser(${user.id})">Delete</button>
                </div>
            </div>
        `).join('');
    }

    updatePagination() {
        const totalPages = Math.ceil(this.users.length / this.usersPerPage);
        this.pagination.pageInfo.textContent = `Page ${this.currentPage} of ${totalPages}`;
        this.pagination.prevBtn.disabled = this.currentPage === 1;
        this.pagination.nextBtn.disabled = this.currentPage === totalPages;
    }

    changePage(delta) {
        this.currentPage += delta;
        this.renderUsers();
        this.updatePagination();
    }

    async editUser(id) {
        try {
            const user = await API.getUser(id);
            this.showModal(user);
        } catch (error) {
            this.showError(error.message);
        }
    }

    async deleteUser(id) {
        if (!confirm('Are you sure you want to delete this user?')) return;

        try {
            await API.deleteUser(id);
            this.users = this.users.filter(user => user.id !== id);
            this.renderUsers();
            this.updatePagination();
        } catch (error) {
            this.showError(error.message);
        }
    }

    showModal(user = null) {
        this.modalTitle.textContent = user ? 'Edit User' : 'Add New User';
        if (user) {
            document.getElementById('userId').value = user.id;
            const [firstName, ...lastName] = user.name.split(' ');
            document.getElementById('firstName').value = firstName;
            document.getElementById('lastName').value = lastName.join(' ');
            document.getElementById('email').value = user.email;
            document.getElementById('department').value = user.company.name;
        } else {
            this.userForm.reset();
            document.getElementById('userId').value = '';
        }
        this.userModal.style.display = 'block';
    }

    closeModal() {
        this.userModal.style.display = 'none';
        this.userForm.reset();
    }

    async handleSubmit(e) {
        e.preventDefault();
        const userId = document.getElementById('userId').value;
        const userData = {
            name: `${document.getElementById('firstName').value} ${document.getElementById('lastName').value}`.trim(),
            email: document.getElementById('email').value,
            company: {
                name: document.getElementById('department').value
            }
        };

        try {
            if (userId) {
                await API.updateUser(userId, userData);
                const index = this.users.findIndex(user => user.id === parseInt(userId));
                this.users[index] = {
                    ...this.users[index],
                    ...userData
                };
            } else {
                const newUser = await API.createUser(userData);
                this.users.unshift({
                    ...newUser,
                    ...userData
                });
            }
            this.closeModal();
            this.renderUsers();
            this.updatePagination();
        } catch (error) {
            this.showError(error.message);
        }
    }

    showError(message) {
        this.errorContainer.textContent = message;
        this.errorContainer.style.display = 'block';
        setTimeout(() => {
            this.errorContainer.style.display = 'none';
        }, 3000);
    }
}

const userService = new UserService();